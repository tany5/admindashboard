import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editsubject',
  templateUrl: './editsubject.component.html',
  styleUrls: ['./editsubject.component.scss']
})
export class EditsubjectComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
