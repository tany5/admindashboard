import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-super-admindashboard',
  templateUrl: './super-admindashboard.component.html',
  styleUrls: ['./super-admindashboard.component.scss']
})
export class SuperAdmindashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
