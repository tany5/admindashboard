import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testmanager',
  templateUrl: './testmanager.component.html',
  styleUrls: ['./testmanager.component.scss']
})
export class TestmanagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
